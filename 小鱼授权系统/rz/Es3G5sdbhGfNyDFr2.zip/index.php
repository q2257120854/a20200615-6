/<html>
<head>
    <title>此站被黑购买请联系:435184519</title>
    <link rel="shortcut icon"
          >
    <embed src="" autostart=true loop=infinite width=0 height=0/>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <STYLE type=text/css>BODY {
        SCROLLBAR-FACE-COLOR: #000000;
        SCROLLBAR-HIGHLIGHT-COLOR: #000000;
        SCROLLBAR-SHADOW-COLOR: #000000;
        SCROLLBAR-3DLIGHT-COLOR: #000000;
        SCROLLBAR-ARROW-COLOR: #ffffff;
        SCROLLBAR-TRACK-COLOR: #ffffff;
        FONT-FAMILY: Verdana;
        SCROLLBAR-DARKSHADOW-COLOR: #000000
    }
 
    .Estilo10 {
        COLOR: #ffffff;
        FONT-FAMILY: Haettenschweiler
    }
 
    .Estilo8 {
        FONT-SIZE: 10px;
        COLOR: #ffffff;
        FONT-FAMILY: Haettenschweiler
    }
    </STYLE>
<body>
<SCRIPT language=JavaScript1.2>
    if (document.all)
        document.body.style.cssText = "border:30 ridge red"
</SCRIPT>
<BGSOUND balance=0 src="http://www.hac-ker.com/hacker.mid" volume=0 loop=20></TR>
    <STYLE type=text/css>
        BODY {
            cursor: url('http://www.hac-ker.com/mouse.cur');
        }
 
        A {
            CURSOR: url('http://www.hac-ker.com/mouse1.cur');
        }
    </STYLE>
    <center>
        <body background="http://www.hac-ker.com/hacker/images/37_01.gif">
        <P class=style1 align="center">
            <center>
                      	<img class="img-circle m-b-xs" style="border: 2px solid yellow; margin-left:3px; margin-right:3px;" src="//q4.qlogo.cn/headimg_dl?dst_uin=435184519&spec=100" width="84px" height="84px" alt="" data-toggle="modal" data-target="#tips_help1"><center>

		            </div>
            <BODY text=#ffffff vLink=#ffffff aLink=#ffffff link=#ff0000 bgColor=#000000>
        <p align="center"><font face="Fixedsys"><font color="#ff0018"><font color=red><font size=6><strong>当前网站的违规行为</strong></font></font>
            <p align="center"><font face="Fixedsys"><font color="#ff0018"><font color=red><font size=6><strong>（参与制作或传播盗版程序并赚取利益、低价倒卖授权等）</strong></font></font>
        <p align="center"><font face="Fixedsys"><font color=white><font size=6><strong><font color="#ff0018">严重违反小鱼自助下单授权协议，已位于黑名单中，永久封禁授权！QQ:435184519
            </strong></font></font>
        <p align="center"><font face="Fixedsys"><font color=yellow><font size=6><strong><a href="http://aa14.club/" target="_blank"><font color="#ff0018">点击此处购买授权</a></strong></font></font>
        <p align="center">
<span class="style2">
            <font face="Courier New">
            <strong style="font-weight: 400">
            <font color="blue" size="6"><font color="#ff0018">小鱼 QQ435184519</font>
            <p align="center"><font face="Fixedsys"><font color="#ff0018"><font color=red><font size=7><strong>😱</strong></font></font>
            <p align="center"><font face="Fixedsys"><font color="#ff0018"><font color=red><font size=7><strong>😱😱</strong></font></font>
            <p align="center"><font face="Fixedsys"><font color="#ff0018"><font color=red><font size=7><strong>😱😱😱</strong></font></font>
            <p align="center"><font face="Fixedsys"><font color="#ff0018"><font color=red><font size=7><strong>😱😱😱😱</strong></font></font>
            <p align="center"><font face="Fixedsys"><font color="#ff0018"><font color=red><font size=7><strong>😱😱😱😱😱</strong></font></font>
            <p align="center"><font face="Fixedsys"><font color="#ff0018"><font color=red><font size=7><strong>😱😱😱😱😱😱</strong></font></font>
            <p align="center"><font face="Fixedsys"><font color="#ff0018"><font color=red><font size=7><strong>😱😱😱😱😱😱😱</strong></font></font>
            <p align="center"><font face="Fixedsys"><font color="#ff0018"><font color=red><font size=7><strong>😱😱😱😱😱😱😱😱</strong></font></font>
            <p align="center"><font face="Fixedsys"><font color="#ff0018"><font color=red><font size=7><strong>😱😱😱😱😱😱😱😱😱</strong></font></font>
            <p align="center"><font face="Fixedsys"><font color="#ff0018"><font color=red><font size=7><strong>😱😱😱😱😱😱😱😱😱😱</strong></font></font>
            <p align="center"><font face="Fixedsys"><font color="#ff0018"><font color=red><font size=7><strong>😱😱😱😱😱😱😱😱😱😱😱</strong></font></font>
        </body>
          <audio autoplay="autoplay" loop>
	<source src="http://boscdn.djduoduo.com/dj/580/sujicha.aac" type="audio/mpeg">
</audio>
</html>