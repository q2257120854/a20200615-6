<?php
include_once '../includes/common.php';
include_once './head.php';
$act = $_GET['act'];
if($act == 'sure_update'){
	$az_url = 'http://  /pack/update.zip';
	$data_az = get_curl($az_url);
    @file_put_contents('./update.zip',$data_az);
    $zip = new ZipArchive;
    $zip->open('./update.zip') && $zip->extractTo('../');
    showmsg('更新程序成功！CEO is create file!',1);
	exit();
}


$check_url = 'http://auth.782km.com/data/check.php?url='.$_SERVER['HTTP_HOST'].'&ver='.VERSION;
$data = get_curl($check_url);
$data_json = json_decode($data,true);

echo '
<!--CEO版权编写文件,勿改版权-->
<div class="block">
<div class="block-title"><h3 class="panel-title">系统在线更新</h3></div>
<div class="">
<pre>
'.($data_json['msg']==''?'更新服务器去泡妞了,请刷新重试！':$data_json['msg']).'
</pre>
<code>更新日志：</code>
<br>
<pre>
'.($data_json['log']==''?'暂无更新日志哦！！':$data_json['log']).'
</pre>
<hr>
'.($data_json['version']>VERSION?'<a href="./act=sure_update" class="btn btn-block btn-warning">开始更新</a>':'<a href="#" class="btn btn-block btn-warning">无需更新</a>').'
</div>
</div>
';
?>